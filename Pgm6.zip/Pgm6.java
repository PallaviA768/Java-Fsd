package AssistedProjectPhase1;
import java.util.HashMap;

import java.util.Map;

public class Pgm6 {
public static void main(String[] args) {
	        // Creating a HashMap
	        Map<String, Integer> studentScores = new HashMap<>();

	        // Adding elements to the HashMap
	        studentScores.put("John", 85);
	        studentScores.put("Emily", 90);
	        studentScores.put("Michael", 78);
	        studentScores.put("Sophia", 95);

	        // Accessing elements from the HashMap
	        System.out.println("John's score: " + studentScores.get("John"));
	        System.out.println("Sophia's score: " + studentScores.get("Sophia"));

	        // Updating an element in the HashMap
	        studentScores.put("John", 88);
	        System.out.println("Updated John's score: " + studentScores.get("John"));

	        // Removing an element from the HashMap
	        studentScores.remove("Michael");
	        System.out.println("Student scores after removing Michael: " + studentScores);

	        // Iterating over the HashMap
	        System.out.println("Iterating over the student scores:");
	        for (Map.Entry<String, Integer> entry : studentScores.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }

	        // Checking if a key exists in the HashMap
	        String name = "Emily";
	        if (studentScores.containsKey(name)) {
	            System.out.println(name + "'s score exists in the map.");
	        } else {
	            System.out.println(name + "'s score does not exist in the map.");
	        }

	        // Checking if a value exists in the HashMap
	        int score = 90;
	        if (studentScores.containsValue(score)) {
	            System.out.println("Score " + score + " exists in the map.");
	        } else {
	            System.out.println("Score " + score + " does not exist in the map.");
	        }

	        // Getting the size of the HashMap
	        System.out.println("Number of students: " + studentScores.size());

	        // Clearing the HashMap
	        studentScores.clear();
	        System.out.println("Student scores after clearing: " + studentScores);
	    }
	
	

}
