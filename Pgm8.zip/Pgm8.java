package AssistedProjectPhase1;

public class Pgm8 {
	
	    public static void main(String[] args) {
	        // Creating a String
	        String originalString = "Hello, this is a String.";

	        // Converting String to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(originalString);
	        System.out.println("StringBuffer: " + stringBuffer);

	        // Converting String to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(originalString);
	        System.out.println("StringBuilder: " + stringBuilder);
	    }
	}


