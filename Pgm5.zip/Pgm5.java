package AssistedProjectPhase1;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Pgm5 {
	       public static void main(String[] args) {

	        // Test ArrayList (ordered, allows duplicates)
	        List<String> names = new ArrayList<>();
	        names.add("Alice");
	        names.add("Bob");
	        names.add("Charlie");
	        names.add("Alice"); // Duplicate allowed

	        System.out.println("Testing ArrayList:");
	        System.out.println("Unique names: " + names); // Order is preserved, duplicates remain

	        // Test HashSet (unordered, no duplicates)
	        Set<Integer> numbers = new HashSet<>();
	        numbers.add(1);
	        numbers.add(2);
	        numbers.add(3);
	        numbers.add(1); // Duplicate ignored

	        System.out.println("\nTesting HashSet:");
	        System.out.println("Unique numbers: " + numbers); // Order may vary, duplicates removed

	        // Additional verification methods:

	        // Check if an element exists
	        if (names.contains("Bob")) {
	            System.out.println("Bob is present in the names list.");
	        }

	        // Get the size of the collection
	        System.out.println("Number of elements in numbers set: " + numbers.size());

	        // Iterate through elements
	        for (String name : names) {
	            System.out.println("Name: " + name);
	        }
	    }
	


}
