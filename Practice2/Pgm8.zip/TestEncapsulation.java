package AssistedProjectPhase2;

public class TestEncapsulation {

}
