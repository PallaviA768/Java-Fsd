package AssistedProjectPhase2;

public class Dog {

}
