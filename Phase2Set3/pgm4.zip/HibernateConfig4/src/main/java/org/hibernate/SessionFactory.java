package org.hibernate;

public class SessionFactory {

}
