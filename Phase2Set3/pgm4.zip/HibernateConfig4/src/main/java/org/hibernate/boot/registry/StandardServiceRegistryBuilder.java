package org.hibernate.boot.registry;

public class StandardServiceRegistryBuilder {

	public Object configure(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
