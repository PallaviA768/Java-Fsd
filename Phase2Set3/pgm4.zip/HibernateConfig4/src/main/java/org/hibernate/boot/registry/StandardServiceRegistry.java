package org.hibernate.boot.registry;

public class StandardServiceRegistry {

}
