package org.hibernate.boot;

public class MetadataSources {

	public Object getMetadataBuilder() {
		// TODO Auto-generated method stub
		return null;
	}

}
