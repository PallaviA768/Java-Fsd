package org.hibernate.boot;

public class Metadata {

	public Object getSessionFactoryBuilder() {
		// TODO Auto-generated method stub
		return null;
	}

}
