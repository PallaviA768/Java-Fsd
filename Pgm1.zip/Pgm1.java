package AssistedProjectPhase1;

public class Pgm1 {
	
	    public static void main(String[] args) {
	        // Implicit type casting (widening)
	        byte b = 10;
	        short s = b;  
	        int i = s;    
	        float f = i;   
	        double d = f;  

	        System.out.println("Implicit type casting:");
	        System.out.println("byte value: " + b);
	        System.out.println("short value: " + s);
	        System.out.println("int value: " + i);
	        System.out.println("float value: " + f);
	        System.out.println("double value: " + d);

	        // Explicit type casting (narrowing)
	        double d2 = 12.55;
	        int i2 = (int) d2;  
	        byte b2 = (byte) i2;  

	        System.out.println("\nExplicit type casting:");
	        System.out.println("Original double value: " + d2);
	        System.out.println("Integer value after casting: " + i2);
	        System.out.println("Byte value after casting: " + b2);
	    }
	}



