package AssistedProjectPhase1;

public class Pgm4 {
	

	    private String name;
	    private int age;

	    // Default constructor
	    public Pgm4() {
	        System.out.println("Default constructor called!");
	        this.name = "John Doe";
	        this.age = 25;
	    }

	    // Parameterized constructor
	    public Pgm4(String name, int age) {
	        System.out.println("Parameterized constructor called!");
	        this.name = name;
	        this.age = age;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	    public static void main(String[] args) {
	        // Create object using default constructor
	        Pgm4 obj1 = new Pgm4();
	        System.out.println("Object 1: Name - " + obj1.getName() + ", Age - " + obj1.getAge());

	        // Create object using parameterized constructor
	        Pgm4 obj2 = new Pgm4("Alice", 30);
	        System.out.println("Object 2: Name - " + obj2.getName() + ", Age - " + obj2.getAge());
	    }
	


}
