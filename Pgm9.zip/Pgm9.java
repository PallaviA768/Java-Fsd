package AssistedProjectPhase1;

public class Pgm9 {
	
	
	    public static void main(String[] args) {
	        // Declaring and initializing an array of integers
	        int[] numbers = {10, 20, 30, 40, 50};

	        // Accessing elements of the array
	        System.out.println("Elements of the array:");
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println("Element at index " + i + ": " + numbers[i]);
	        }

	        // Modifying an element of the array
	        numbers[2] = 35;
	        System.out.println("Modified array:");
	        for (int number : numbers) {
	            System.out.print(number + " ");
	        }
	        System.out.println(); // New line

	        // Declaring and initializing a 2D array
	        int[][] matrix = {
	                {1, 2, 3},
	                {4, 5, 6},
	                {7, 8, 9}
	        };

	        // Accessing elements of the 2D array
	        System.out.println("Elements of the 2D array:");
	        for (int i = 0; i < matrix.length; i++) {
	            for (int j = 0; j < matrix[i].length; j++) {
	                System.out.println("Element at index [" + i + "][" + j + "]: " + matrix[i][j]);
	            }
	        }
	    }
	

}
