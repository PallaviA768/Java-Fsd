package AssistedProjectPhase1;

public class Pgm3 {

	    // Method without parameters and return type
	    public static void greet() {
	        System.out.println("Hello! Welcome to Method Example");
	    }

	    // Method with parameters and return type
	    public static int add(int a, int b) {
	        return a + b;
	    }

	    // Method with parameters and void return type
	    public static void display(String message) {
	        System.out.println("Message: " + message);
	    }

	    public static void main(String[] args) {
	        // Calling a method without parameters and return type
	        greet();

	        // Calling a method with parameters and return type
	        int result = add(5, 3);
	        System.out.println("Result of addition: " + result);

	        // Calling a method with parameters and void return type
	        display("Java Programming");

	        // Another way of calling methods with parameters and return type
	        int x = 10;
	        int y = 20;
	        int sum = add(x, y);
	        System.out.println("Sum: " + sum);
	    }
	

}
