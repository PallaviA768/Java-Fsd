package AssistedProjectPhase1;

public class Pgm2 {
	

	    private String privateName = "This is private";
	    protected String protectedName = "This is protected";
	    public String publicName = "This is public";

	    // Getter method for accessing protected variable
	    public String getProtectedName() {
	        return protectedName;
	    }

	    public static void main(String[] args) {
	        Pgm2 obj = new Pgm2();

	        // Accessing public member directly
	        System.out.println("Public attribute: " + obj.publicName);

	        // Accessing protected member using getter method
	        System.out.println("Protected attribute (using getter): " + obj.getProtectedName());

	       
	    }
	


}
