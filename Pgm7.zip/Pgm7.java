package AssistedProjectPhase1;

public class Pgm7 {
	
	    private int outerData = 10;

	    // Inner class
	    public class InnerClass {
	        public void display() {
	            System.out.println("Inner class method: outerData = " + outerData);
	        }
	    }

	    public static void main(String[] args) {
	       Pgm7 outerObject = new Pgm7();
	        
	        // Creating an instance of the inner class
	        Pgm7.InnerClass innerObject = outerObject.new InnerClass();
	        
	        // Accessing the method of the inner class
	        innerObject.display();
	    }
	

}
